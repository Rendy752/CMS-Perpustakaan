
<link
    href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
    rel="stylesheet">
<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
<?php $__env->startSection('content'); ?>
<div class="container-fluid py-5">
    <div class="text-center">
        <div class="error mx-auto" data-text="403">403</div>
        <p class="lead text-gray-800 mb-5">THIS ACTION IS UNAUTHORIZED</p>
        <a href="/home">&larr; Back to Dashboard</a>
    </div>
</div>

</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\Perpustakaan\resources\views/errors/403.blade.php ENDPATH**/ ?>