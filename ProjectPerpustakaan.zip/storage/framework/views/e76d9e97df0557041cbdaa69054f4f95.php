<div class="modal fade" role="dialog" id="profil" data-bs-backdrop="static" data-bs-keyboard="false" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border-radius: 1.5rem;">
            <div class="container h-100">
                <div class="row d-flex justify-content-center align-items-center h-100">
                    <div class="card bg-dark text-white" style="border-radius: 1rem;">
                        <button class="btn-close btn-close-white ms-auto p-4 " aria-label="Close" data-bs-dismiss="modal"></button>
                        <div class="card-body px-4 pb-5 text-center">
                            <div class="mb-md-5 mt-md-4 pb-5">
                                <div><i class="fa fa-user-circle fa-5x mb-2"></i></div>
                                <h2 class="fw-bold text-uppercase">Profil</h2>
                                <?php if(Auth::user()->role=='A'): ?>
                                    <div class="mb-5"><span class="bg-warning rounded p-2"><i class="fas fa-user-cog"></i><strong> Admin</strong></span></div>
                                <?php else: ?>
                                    <div class="mb-5"><span class="bg-success rounded p-2"><i class="fas fa-user-check"></i><strong> User</strong></span></div>
                                <?php endif; ?>
                                <form action="/profile" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('patch'); ?>
                                    <div class="form-outline form-white mb-4">
                                        <input type="text" name="name_profile" class="form-control form-control-lg"
                                            placeholder="Name" value="<?php echo e(Auth::user()->name); ?>" required />
                                        <?php $__errorArgs = ['name_profile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger">&times <?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-outline form-white mb-4">
                                        <input type="email" class="form-control form-control-lg"
                                            placeholder="Email" value="<?php echo e(Auth::user()->email); ?>" disabled />
                                    </div>
                                    <button class="btn btn-outline-light btn-lg px-5 mt-4" type="submit">Update</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php /**PATH D:\Laravel\Perpustakaan\resources\views/profile.blade.php ENDPATH**/ ?>