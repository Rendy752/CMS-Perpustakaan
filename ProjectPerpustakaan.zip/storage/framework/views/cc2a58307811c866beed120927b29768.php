
<?php $__env->startSection('content'); ?>
<div class="card mb-4">
    <div class="text-center card-header">
        <i class="fas fa-book mt-3"></i> Book -> <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#add">&plus;</button>
        <?php echo $__env->make('buku.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row my-3 px-sm-5">
            <label class="col-form-label mt-3 col-4"><h5>Filter :</h5></label>
            <div class="col-8">
                <select name="kategori" class="h-100 col-md-12 rounded form-select" onchange="window.location.href=this.value">
                    <option>-> Pilih Kategori <-</option>
                    <option value=<?php echo e(route('buku.index')); ?>>All</option>
                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e(route('buku.show', $data->id)); ?>" 
                        value="<?php echo e($data->id); ?>"><?php echo e($data->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    </div>
    <div class="p-4">
        <div
            class='container-fluid card-container d-flex justify-content-center align-items-center gap-5 flex-wrap'>
            <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <section class="fw-bolder float-left card col-lg-3 col-md-4 shadow p-3">
                <img src="<?php echo e(asset('foto/'.$data->cover)); ?>" class="rounded shadow border border-dark"style="width: auto; height: 15rem;">
                <div class="text-center mb-3">Download here -><a href="<?php echo e(asset('file/'.$data->file)); ?>" target="_blank" style="width: 2rem; height: 2rem;"><?php echo e($data->file); ?></a></div>
                
                <table>
                    <?php if(Auth::user()->role==='A'): ?> 
                    <tr>
                        <td>ID</td>
                        <td>=></td>
                        <td><?php echo e($data->id); ?></td>
                    </tr>
                    <tr>
                        <td>User</td>
                        <td>=></td>
                        <td><?php echo e($data->user->name); ?></td>
                    </tr>
                    <?php endif; ?>
                    <section class="text-center mt-1"><h2><?php echo e($data->judul); ?></h2></section>
                    <section class="text-center mt-1 mb-2"><h3>-- <?php echo e($data->kategori->nama); ?> --</h3></section>
                    <div class="bg-primary rounded shadow ps-2">
                        <span class="bg-warning rounded shadow p-2">Deskripsi</span>
                        <p class="mt-2"><?php echo e($data->deskripsi); ?></p>
                    </div>
                    <span class="text-center mt-3 bg-success rounded shadow py-2">Jumlah<hr><?php echo e($data->jumlah); ?></span>
                </table>
                <div class="text-center mt-3">
                    <a class="btn btn-secondary border border-light rounded py-2 px-3 shadow" href="<?php echo e(route('buku.edit',$data->id)); ?>"><i
                        class="fas fa-edit text-warning"></i></a>
                    <a class="btn btn-secondary border border-light rounded py-2 px-3 shadow" href=<?php echo e("buku/delete/".$data->id); ?>><i
                        class="fa fa-trash text-danger"></i></a>
                </div>
            </section>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->startSection('error'); ?>
<?php if($errors->has('judul')||$errors->has('deskripsi')||$errors->has('jumlah')||$errors->has('cover')||$errors->has('file')): ?>
    <script>
        $(document).ready(function () {
            $('#add').modal('show')
        })
    </script>
<?php elseif($errors->has('judul_edit')||$errors->has('deskripsi_edit')||$errors->has('jumlah_edit')||$errors->has('cover_edit')||$errors->has('file_edit')||session()->has('update')): ?>
<?php echo $__env->make('buku.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(document).ready(function () {
        $('#edit').modal('show')
    })
</script>
<?php elseif(session()->has('delete')): ?>
<?php echo $__env->make('buku.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(document).ready(function () {
        $('#delete').modal('show')
    })
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\Perpustakaan\resources\views/buku/index.blade.php ENDPATH**/ ?>