
<?php $__env->startSection('content'); ?>
<div class="card mb-4">
    <div class="text-center card-header">
        <i class="fa fa-tag"></i> Category -> <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#add">&plus;</button>
        <?php echo $__env->make('kategori.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="p-4">
        <div
            class='container-fluid card-container d-flex justify-content-center align-items-center gap-5 flex-wrap'>
            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <section class="fw-bolder float-left card col-lg-3 col-md-4 shadow p-3 text-center rounded-circle">
                <h2><?php echo e($data->nama); ?></h2>
                <?php $__currentLoopData = $jumlah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($data2->id==$data->id): ?>
                        <h3>Jumlah = <?php echo e($data2->jumlah); ?></h3>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(Auth::user()->role==='A'): ?> 
                <div class="mt-3">
                    <a class="btn btn-secondary border border-light rounded py-2 px-3 shadow" href=<?php echo e("kategori/edit/".$data->id); ?>><i
                            class="fas fa-edit text-warning"></i></a>
                    <a class="btn btn-secondary border border-light rounded py-2 px-3 shadow" href=<?php echo e("kategori/delete/".$data->id); ?>><i
                            class="fa fa-trash text-danger"></i></a>
                </div>
                <?php endif; ?>
            </section>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->startSection('error'); ?>
<?php if($errors->has('nama')): ?>
    <script>
        $(document).ready(function () {
            $('#add').modal('show')
        })
    </script>
<?php elseif($errors->has('nama_edit')||session()->has('update')): ?>
<?php echo $__env->make('kategori.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(document).ready(function () {
        $('#edit').modal('show')
    })
</script>
<?php elseif(session()->has('delete')): ?>
<?php echo $__env->make('kategori.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(document).ready(function () {
        $('#delete').modal('show')
    })
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\Perpustakaan\resources\views/kategori/index.blade.php ENDPATH**/ ?>