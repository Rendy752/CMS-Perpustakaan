<div class="modal fade" role="dialog" id="edit" data-bs-backdrop="static" data-bs-keyboard="false" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border-radius: 1.5rem;">
            <div class="container h-100">
                <div class="row d-flex justify-content-center align-items-center h-100">
                    <div class="card bg-primary text-dark" style="border-radius: 1rem;">
                        <button class="btn-close btn-close-white ms-auto p-4 " aria-label="Close"
                            data-bs-dismiss="modal"></button>
                        <div class="card-body px-5 pb-2 text-center">
                            <div class="mb-md-5 mt-md-4">
                                <h2 class="fw-bold mb-2 text-uppercase mb-4">Update Book</h2>
                                
                                <form action="<?php echo e(route('buku.update', session('update'))); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('patch'); ?>
                                    <div class="form-outline form-white mb-4">
                                        <div class="form-floating mb-3">
                                            <input class="form-control mt-3" name="judul_edit" type="text" placeholder="Judul" value="<?php echo e(session('update')->judul); ?>" required/>
                                            <label>Judul</label>
                                            <?php $__errorArgs = ['judul_edit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger">&times <?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="row mb-3">
                                            <label class="col-form-label mt-3 col-4"><h5>Kategori :</h5></label>
                                            <div class="col-8">
                                                <select name="kategori" class="h-100 col-md-12 rounded form-select">
                                                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php if(session('update')->kategori_id==$data->id): ?> selected <?php endif; ?> value="<?php echo e($data->id); ?>"><?php echo e($data->nama); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <textarea class="form-control mt-3" name="deskripsi_edit" rows="5" cols="50" placeholder="Deskripsi" required><?php echo e(session('update')->deskripsi); ?></textarea>
                                            <label>Deskripsi</label>
                                            <?php $__errorArgs = ['deskripsi_edit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger">&times <?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control mt-3" name="jumlah_edit" type="number" placeholder="Jumlah" value="<?php echo e(session('update')->jumlah); ?>" min="1" required/>
                                            <label>Jumlah</label>
                                            <?php $__errorArgs = ['jumlah_edit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger">&times <?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <img src="<?php echo e(asset('foto/'.session('update')->cover)); ?>" class="rounded shadow border border-dark"style="width: auto; height: 15rem;">
                                        <div class="row mb-3">
                                            <label class="col-form-label mt-3 col-4"><h5>Cover :</h5></label>
                                            <div class="col-8">
                                                <input type="file" name="cover_edit" class="form-control form-control-lg mt-3"
                                                    placeholder="Cover" />
                                            </div>
                                            <?php $__errorArgs = ['cover_edit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger">&times <?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <a href="<?php echo e(asset('file/'.session('update')->file)); ?>" target="_blank" class="text-warning" style="width: 2rem; height: 2rem;" download="<?php echo e(session('update')->file); ?>">Current file -> <?php echo e(session('update')->file); ?></a>
                                        <div class="row mb-3">
                                            <label class="col-form-label mt-3 col-4"><h5>File :</h5></label>
                                            <div class="col-8">
                                                <input type="file" name="file_edit" class="form-control form-control-lg mt-3"
                                                    placeholder="File" />
                                            </div>
                                            <?php $__errorArgs = ['file_edit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger">&times <?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row d-flex justify-content-center gap-5">
                                        <button class="btn btn-outline-light btn-danger btn-lg px-5 mt-4 shadow col-5" type="reset">Reset</button>
                                        <button class="btn btn-outline-light btn-warning btn-lg px-5 mt-4 shadow col-5" type="submit">Update</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /**PATH D:\Laravel\Perpustakaan\resources\views/buku/edit.blade.php ENDPATH**/ ?>