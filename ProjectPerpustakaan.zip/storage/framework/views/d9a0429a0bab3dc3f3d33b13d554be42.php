<div class="modal fade" role="dialog" id="add" data-bs-backdrop="static" data-bs-keyboard="false" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border-radius: 1.5rem;">
            <div class="container h-100">
                <div class="row d-flex justify-content-center align-items-center h-100">
                    <div class="card bg-primary text-dark" style="border-radius: 1rem;">
                        <button class="btn-close btn-close-white ms-auto p-4 " aria-label="Close"
                            data-bs-dismiss="modal"></button>
                        <div class="card-body px-5 pb-2 text-center">
                            <div class="mb-md-5 mt-md-4">
                                <h2 class="fw-bold mb-2 text-uppercase mb-4">Add Book</h2>
                                <form action="<?php echo e(route('buku.store')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-outline form-white mb-4">
                                        <div class="form-floating mb-3">
                                            <input class="form-control mt-3" name="judul" type="text" placeholder="Judul" value="<?php echo e(old('judul')); ?>" required/>
                                            <label>Judul</label>
                                            <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger">&times <?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="row mb-3">
                                            <label class="col-form-label mt-3 col-4"><h5>Kategori :</h5></label>
                                            <div class="col-8">
                                                <select name="kategori" class="h-100 col-md-12 rounded form-select">
                                                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->nama); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <textarea class="form-control mt-3" name="deskripsi" rows="5" cols="50" placeholder="Deskripsi" required><?php echo e(old('deskripsi')); ?></textarea>
                                            <label>Deskripsi</label>
                                            <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger">&times <?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control mt-3" name="jumlah" type="number" placeholder="Jumlah" value="<?php echo e(old('jumlah')); ?>" min="1" required/>
                                            <label>Jumlah</label>
                                            <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger">&times <?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="row mb-3">
                                            <label class="col-form-label mt-3 col-4"><h5>Cover :</h5></label>
                                            <div class="col-8">
                                                <input type="file" name="cover" class="form-control form-control-lg mt-3"
                                                    placeholder="Cover" required />
                                            </div>
                                            <?php $__errorArgs = ['cover'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger">&times <?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="row mb-3">
                                            <label class="col-form-label mt-3 col-4"><h5>File :</h5></label>
                                            <div class="col-8">
                                                <input type="file" name="file" class="form-control form-control-lg mt-3"
                                                    placeholder="File" required />
                                            </div>
                                            <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger">&times <?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row d-flex justify-content-center gap-5">
                                        <button class="btn btn-outline-light btn-danger btn-lg px-5 mt-4 shadow col-5" type="reset">Reset</button>
                                        <button class="btn btn-outline-light btn-success btn-lg px-5 mt-4 shadow col-5" type="submit">Add</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Laravel\Perpustakaan\resources\views/buku/create.blade.php ENDPATH**/ ?>